# House Price Prediction (Synthetic Dataset)

This is a beginner-friendly regression project using a synthetic house prices dataset (12,000 rows).

## What's included
- `data/house_prices.csv` — synthetic dataset (intentionally unclean)
- `notebook/house_price_prediction.ipynb` — Jupyter notebook with preprocessing, training, evaluation
- `models/trained_model.pkl` — trained RandomForest model + scaler + feature list
- `requirements.txt` — Python packages to install

## How to run
1. (Optional) Create a virtual environment
2. `pip install -r requirements.txt`
3. Open the Jupyter notebook: `jupyter notebook notebook/house_price_prediction.ipynb`

## Notes
- The notebook demonstrates data cleaning (handling missing values and messy types), label encoding, feature scaling, model training, and saving.
- You can upload this whole folder to GitHub as-is.
